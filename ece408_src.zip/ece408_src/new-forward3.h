#ifndef MXNET_OPERATOR_NEW_FORWARD_CUH_
#define MXNET_OPERATOR_NEW_FORWARD_CUH_
#include <mxnet/base.h>
#include <stdio.h>
#include <math.h>
#define MAX_NUM_THREADS 1024
namespace mxnet
{
    namespace op
    {
        
        __global__ void forward_kernel(float *y, float *x, float *k,  const int B, const int M, const int C, const int H, const int W, const int K)
        
        {


            int c, s, h_out, w_out, h_unroll, w_base, p, q, w_unroll,n,m,acc;
            const int H_out = H - K + 1;
            const int W_out = W - K + 1;

            int t=blockIdx.x * MAX_NUM_THREADS + threadIdx.x;
            n = blockIdx.x;
            m = blockIdx.y;
#define y4d(i3, i2) y[(i3) * (M ) + (i2) * (K*K) ]
#define x4d(i3, i2) x[(i3) * (C * H_out * W_out) + (i2) * (K*K) ]
#define k4d(i3, i2) k[(i3) * (M )+ (i2) * (C * H_out * W_out) ]
//#define y4d(i3, i2) y[(i3) * (K*K ) + (i2)  ]
//#define x4d(i3, i2) x[(i3) *  (K*K) + (i2) ]
//#define k4d(i3, i2) k[(i3) * (C * H_out * W_out)+ (i2)  ]

            int W_unroll = H_out * W_out;
            if (t < C * W_unroll){
                c = t / W_unroll;
                s = t% W_unroll;
                h_out = s / W_out;
                w_out=s%W_out;
                h_unroll = h_out * W_out + w_out;
                w_base = c * K * K;
                 //__shared__ float X_unroll[][];
                 //__shared__ float W_unrolled[][];
                 //__shared__ float Y_unroll[][];
                for(p = 0; p < K; p++){
                    for(q = 0; q < K; q++){
                        w_unroll = w_base + p * K + q;
                        //X_unroll[h_unroll][w_unroll] = x4d(n,c, h_out + p, w_out + q);
                        //W_unrolled[m][h_unroll]=k4d(m,c,p,q);
                        acc+=k4d(m,h_unroll)*x4d(h_unroll,w_unroll);
                    }
                }


            y4d(m,w_unroll)=acc;
            }
#undef y4d
#undef x4d
#undef k4d
        }
        template <>
        void forward<gpu, float>(mshadow::Tensor<gpu, 4, float> &y, const mshadow::Tensor<gpu, 4, float> &x, const mshadow::Tensor<gpu, 4, float> &w)
        {
            const int B = x.shape_[0]; //batches
            const int M = y.shape_[1]; //output channels
            const int C = x.shape_[1]; //input channels
            const int H = x.shape_[2]; //height of input
            const int W = x.shape_[3]; //width of input
            const int K = w.shape_[3]; //height and width of weights
            
            const int H_out = H - K + 1;
            const int W_out = W - K + 1;
            int X = ceil((M*K*K)/(MAX_NUM_THREADS*1.0));
            int Y = ceil((B*C * H_out * W_out)/(MAX_NUM_THREADS*1.0));
            //dim3 gridDim(X, Y, 1);
            //dim3 blockDim(TILE_WIDTH,TILE_WIDTH,1);
            
            //forward_kernel<<<gridDim, blockDim>>>(y.dptr_,x.dptr_,w.dptr_, B,M,C,H,W,K);
            //int num_threads = C * H_out * W_out;
            //int num_blocks = ceil((C * H_out * W_out) / 1.0* MAX_NUM_THREADS);

            dim3 gridDim(X,Y,1);
            dim3 blockDim(32.0,32.0,1);
            forward_kernel<<<gridDim, blockDim>>>(y.dptr_,x.dptr_,w.dptr_, B,M,C,H,W,K);
            MSHADOW_CUDA_CALL(cudaDeviceSynchronize());
            
        }
        
        template <typename gpu, typename DType>
        void forward(mshadow::Tensor<gpu, 4, DType> &y, const mshadow::Tensor<gpu, 4, DType> &x, const mshadow::Tensor<gpu, 4, DType> &w)
        {
            //CHECK_EQ(0,1) << "Remove this line and replace it with your implementation.";
        }
    }
}

#endif
