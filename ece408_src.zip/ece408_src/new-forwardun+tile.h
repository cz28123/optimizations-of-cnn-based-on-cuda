#ifndef MXNET_OPERATOR_NEW_FORWARD_CUH_
#define MXNET_OPERATOR_NEW_FORWARD_CUH_

#include <mxnet/base.h>

#define TILE_WIDTH 32

namespace mxnet
{
    namespace op
    {
        
        __global__ void forward_kernel(float *x, float *y, const float *k, const int B, const int M, const int C, const int H, const int W, const int K, int W_grid)
        {


        #define x4d(i3, i2, i1, i0) x[(i3) * (C * H * W) + (i2) * (H * W) + (i1) * (W) + i0]

            const int H_out = H - K + 1;
            const int W_out = W - K + 1;

            int b = blockIdx.z;


            int numAColumns = C*K*K;

            int numBColumns = H_out * W_out;

            int numCRows = M;
            int numCColumns = numBColumns;

            int width = numAColumns;

            __shared__ float tileA[TILE_WIDTH][TILE_WIDTH];
            __shared__ float tileB[TILE_WIDTH][TILE_WIDTH];

            int row = blockIdx.y * TILE_WIDTH + threadIdx.y;
            int col = blockIdx.x * TILE_WIDTH + threadIdx.x;

            float dot_product = 0;
            int x_c, x_h, x_w, x_p, x_q, x_pq;


            for(int tile = 0; tile < (width + TILE_WIDTH-1)/TILE_WIDTH; tile++) {
                if(tile*TILE_WIDTH + threadIdx.x < width && row < numCRows) {
                    tileA[threadIdx.y][threadIdx.x] = k[row*numAColumns + tile*TILE_WIDTH+threadIdx.x];
                }
               // else {
                   // tileA[threadIdx.y][threadIdx.x] = 0.0;
               // }

                if(tile*TILE_WIDTH + threadIdx.y < width && col < numCColumns) {
                    x_c = (tile*TILE_WIDTH+threadIdx.y)/(K*K);
                    x_h = col/W_out;
                    x_w = col%W_out;
                    x_pq = (tile*TILE_WIDTH+threadIdx.y)%(K*K);
                    x_p = x_pq/K;
                    x_q = x_pq%K;
                    tileB[threadIdx.y][threadIdx.x] = x4d(b, x_c, x_h + x_p, x_w + x_q);
                }
                  // else {
                   // tileB[threadIdx.y][threadIdx.x] = 0.0;
               // }
               __syncthreads();

                for(int i = 0; i < TILE_WIDTH; i++) {
                    dot_product += (tileA[threadIdx.y][i] * tileB[i][threadIdx.x]);
                }
                //__syncthreads();

            }
            if(row < numCRows && col < numCColumns) {
                y[(b * M * H_out * W_out) + row*numCColumns + col] = dot_product;
            }


#undef x4d
        }

        template <>
        void forward<gpu, float>(mshadow::Tensor<gpu, 4, float> &y, const mshadow::Tensor<gpu, 4, float> &x, const mshadow::Tensor<gpu, 4, float> &w)
        {
            

            
            const int B = x.shape_[0];
            const int M = y.shape_[1];
            const int C = x.shape_[1];
            const int H = x.shape_[2];
            const int W = x.shape_[3];
            const int K = w.shape_[3];
            
            const int H_out = H - K + 1;
            const int W_out = W - K + 1;
            
            int W_grid = ceil(1.0*W_out/TILE_WIDTH);
            int H_grid = ceil(1.0*H_out/TILE_WIDTH);
            
            int H_unroll = H_out * W_out;
            
            dim3 dimGrid(ceil(1.0*H_unroll/TILE_WIDTH), ceil(1.0*M/TILE_WIDTH), B);
            dim3 dimBlock(TILE_WIDTH, TILE_WIDTH, 1);
            
            forward_kernel<<<dimGrid, dimBlock>>>(x.dptr_, y.dptr_,w.dptr_, B,M,C,H,W,K, W_grid);
            

            MSHADOW_CUDA_CALL(cudaDeviceSynchronize());
            
        }
        

        template <typename gpu, typename DType>
        void forward(mshadow::Tensor<gpu, 4, DType> &y, const mshadow::Tensor<gpu, 4, DType> &x, const mshadow::Tensor<gpu, 4, DType> &w)
        {
        }
    }
}

#endif
