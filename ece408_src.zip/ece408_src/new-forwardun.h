
#ifndef MXNET_OPERATOR_NEW_FORWARD_CUH_
#define MXNET_OPERATOR_NEW_FORWARD_CUH_

#include <mxnet/base.h>

#include <stdio.h>

#include <math.h>

#define TILE_WIDTH 16
#define CUDA_MAX_NUM_THREADS 64

//#define  checkCuda()

namespace mxnet

{

    namespace op

    {



//__constant__ float weightMatrix[24*12*7*7];



     __global__ void unroll_Kernel(int C, int H, int W, int b, int K, float* x, float* X_unroll)
{
	#define x4d(i3, i2, i1, i0) x[(i3) * (C * H * W) + (i2) * (H * W) + (i1) * (W) + i0]
	int c, s, row_out, col_out, col_unroll, row_unroll, w_base, p, q;
	int t = blockIdx.x * CUDA_MAX_NUM_THREADS + threadIdx.x;
	int H_out = H - K + 1;
	int W_out = W - K + 1;
	int W_unroll = H_out * W_out;
	if (t < C * W_unroll) {
		c = t / W_unroll;
		s = t % W_unroll;
		row_out = s / W_out;
		col_out = s % W_out;
		col_unroll = row_out * W_out + col_out;
		w_base = c * K * K;
		for(p = 0; p < K; p++) {
			for(q = 0; q < K; q++) {
				row_unroll = w_base + p * K + q;
				X_unroll[row_unroll * W_unroll + col_unroll] = x4d(b, c, row_out + p, col_out + q);
			}
		}
	}
	#undef x4d
}


  __global__ void matrixMultiplyShared(float *A, float *B, float *C,
                                     int numARows, int numAColumns,
                                     int numBRows, int numBColumns,
                                     int numCRows, int numCColumns) {
  __shared__ float tileA[TILE_WIDTH][TILE_WIDTH];
  __shared__ float tileB[TILE_WIDTH][TILE_WIDTH];

  int col = threadIdx.x + blockIdx.x * TILE_WIDTH;
  int row = threadIdx.y + blockIdx.y * TILE_WIDTH;

  float val = 0;

  for(int i = 0; i < ceil(1.0 * numAColumns / TILE_WIDTH); i++) {
    if(row < numARows && (i * TILE_WIDTH + threadIdx.x) < numAColumns) {
      tileA[threadIdx.y][threadIdx.x] = A[row * numAColumns + (i * TILE_WIDTH + threadIdx.x)];
    } else {
      tileA[threadIdx.y][threadIdx.x] = 0;
    }

    if(col < numBColumns && (i * TILE_WIDTH + threadIdx.y) < numBRows) {
      tileB[threadIdx.y][threadIdx.x] = B[(i * TILE_WIDTH + threadIdx.y) * numBColumns + col];
    } else {
      tileB[threadIdx.y][threadIdx.x] = 0;
    }
    __syncthreads();

    for(int i = 0; i < TILE_WIDTH; i++) {
      val += tileA[threadIdx.y][i] * tileB[i][threadIdx.x];
    }

    __syncthreads();
  }

  if(row < numCRows && col < numCColumns) {
    C[row * numCColumns + col] = val;
  }
}


        template<>

        void forward<gpu, float>(mshadow::Tensor<gpu, 4, float> &y, const mshadow::Tensor<gpu, 4, float> &x, const mshadow::Tensor<gpu,4,float> &w)

        {





            const int B = x.shape_[0]; // input batch

            const int M = w.shape_[1]; // output channel number

            const int C = x.shape_[1]; // input channel number

            const int H = x.shape_[2]; // input height

            const int W = x.shape_[3]; // input width

            const int K = w.shape_[3]; // kernel size

            const int H_out = H - K + 1;
            const int W_out = W - K + 1;

            int W_unroll = H_out * W_out;
	        int H_unroll = C * K * K;

	float* X_unrolled;
	cudaMalloc((void **) &X_unrolled, W_unroll * H_unroll * sizeof(float));

	dim3 dimBlock(TILE_WIDTH, TILE_WIDTH, 1);
	dim3 dimGrid(ceil((1.0 * W_unroll)/TILE_WIDTH), ceil((1.0 * M)/TILE_WIDTH), 1);

	int num_blocks = ceil((1.0 * C * H_out * W_out) / CUDA_MAX_NUM_THREADS);

		float* curr_output = &y.dptr_[B * M * H_out * W_out];
		unroll_Kernel<<<num_blocks, CUDA_MAX_NUM_THREADS>>>(C, H, W, B, K, x.dptr_, X_unrolled);

		matrixMultiplyShared<<<dimGrid, dimBlock>>>(w.dptr_, X_unrolled, curr_output,
													M, H_unroll,
													H_unroll, W_unroll,
													M, W_unroll);


    // Use MSHADOW_CUDA_CALL to check for CUDA runtime errors.
    MSHADOW_CUDA_CALL(cudaDeviceSynchronize());

}

        template <typename gpu, typename DType>

        void forward(mshadow::Tensor<gpu, 4, DType> &y, const mshadow::Tensor<gpu, 4, DType> &x, const mshadow::Tensor<gpu, 4, DType> &w)

        {

            //CHECK_EQ(0,1) << "Remove this line and replace it with your implementation.";

        }

    }

}







#endif
