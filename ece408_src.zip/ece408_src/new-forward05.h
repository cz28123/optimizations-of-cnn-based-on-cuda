
#ifndef MXNET_OPERATOR_NEW_FORWARD_CUH_
#define MXNET_OPERATOR_NEW_FORWARD_CUH_
#define CUDA_MAX_NUM_THREADS 1024
#include <mxnet/base.h>

namespace mxnet
{
namespace op
{

#define TILE_SIZE 32.0
#define TILE_SIZE_ 32
__constant__ float deviceKernel[14112];

__global__ void unroll_Kernel(const int C, const int H, const int W, const int K, float *X, float *X_unrolled)
{
    int c, s, h_out, w_out, w_unroll, h_unroll, p, q;
    int t = blockIdx.x * CUDA_MAX_NUM_THREADS + threadIdx.x;
    int H_out = H - K + 1;
    int W_out = W - K + 1;
    int W_unroll = H_out * W_out;
    int H_unroll = C * K * K;

    if(t < C * K * K * W_unroll)
    {
        c = t / (K * K * W_unroll);
        s = t % (K * K * W_unroll);
        w_unroll = t % W_unroll;
        h_unroll = t / W_unroll;
        p = s / W_unroll / K;
        q = s / W_unroll % K;
        h_out = w_unroll / W_out;
        w_out = w_unroll % W_out;
        X_unrolled[h_unroll * W_unroll + w_unroll] = X[c * H * W + (h_out + p) * W + w_out + q];
    }

    __syncthreads();
}

__global__ void gemm_Kernel(const int M, const int H_unroll, const int W_unroll, float *X_unrolled, float *y)
{
    __shared__ float input[TILE_SIZE_ * TILE_SIZE_];
    __shared__ float localkernel[TILE_SIZE_ * TILE_SIZE_];

    int tx = threadIdx.x, ty = threadIdx.y;
    int bx = blockIdx.x, by = blockIdx.y;
    int row = by * TILE_SIZE + ty, col = bx * TILE_SIZE + tx;
    float result = 0;

    #pragma unroll
    for(int ph = 0;ph < ceil(H_unroll / TILE_SIZE);ph++)
    {
        if(ph * TILE_SIZE + ty < H_unroll && col < W_unroll)
            input[ty * TILE_SIZE_ + tx] = X_unrolled[(ph * TILE_SIZE_ + ty) * W_unroll + col];
        else
            input[ty * TILE_SIZE_ + tx] = 0;
        if(row < M && ph * TILE_SIZE + tx < H_unroll)
            localkernel[ty * TILE_SIZE_ + tx] = deviceKernel[row * H_unroll + ph * TILE_SIZE_ + tx];
        else
            localkernel[ty * TILE_SIZE_ + tx] = 0;

        __syncthreads();
        #pragma unroll
        for(int i = 0;i < TILE_SIZE;i++)
            result += localkernel[ty * TILE_SIZE_ + i] * input[i * TILE_SIZE_ + tx];
        __syncthreads();

    }
    if(row < M && col < W_unroll)
        y[row * W_unroll + col] = result;
    
}

template <>
void forward<gpu, float>(mshadow::Tensor<gpu, 4, float> &y, const mshadow::Tensor<gpu, 4, float> &x, const mshadow::Tensor<gpu, 4, float> &w)
{


    const int B = x.shape_[0];
    const int M = y.shape_[1];
    const int C = x.shape_[1];
    const int H = x.shape_[2];
    const int W = x.shape_[3];
    const int K = w.shape_[2];
    const int H_out = H - K + 1;
    const int W_out = W - K + 1;
    const int W_unroll = H_out * W_out;
    const int H_unroll = C * K * K;
    float *X_unrolled;
    cudaMalloc((void **)&X_unrolled, 20 * W_unroll * H_unroll * sizeof(float));
    cudaStream_t s = y.stream_->stream_;
    cudaStream_t stream[20];

    for(int i = 0;i < 20;i++)
        cudaStreamCreate(&stream[i]);

    cudaMemcpyToSymbol(deviceKernel, w.dptr_, sizeof(float) * K * K * M * C, 0, cudaMemcpyHostToDevice);
  
    for(int i = 0;i < 500;i++)
    {
        for(int j = 0;j < 20;j++)
        {
            int n = i * 20 + j;
            unroll_Kernel<<<ceil((H_unroll * W_unroll) * 1.0 /CUDA_MAX_NUM_THREADS), CUDA_MAX_NUM_THREADS, 0, stream[j]>>>(C, H, W, K ,&(((float *)x.dptr_)[n * C * H * W]), &X_unrolled[j * W_unroll * H_unroll]);
            dim3 dimBlock(TILE_SIZE, TILE_SIZE, 1);
            dim3 dimGrid(ceil(W_unroll / TILE_SIZE), ceil(M / TILE_SIZE), 1);
            gemm_Kernel<<<dimGrid, dimBlock, 0, stream[j]>>>(M, H_unroll, W_unroll, &X_unrolled[j * W_unroll * H_unroll], &(((float *)y.dptr_)[n * M * W_unroll]));
        }
    }



}

template <typename gpu, typename DType>
void forward(mshadow::Tensor<gpu, 4, DType> &y, const mshadow::Tensor<gpu, 4, DType> &x, const mshadow::Tensor<gpu, 4, DType> &w)
{
    //CHECK_EQ(0,1) << "Remove this line and replace it with your implementation.";
}
}
}

#endif

