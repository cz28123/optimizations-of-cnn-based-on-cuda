#ifndef MXNET_OPERATOR_NEW_FORWARD_CUH_
#define MXNET_OPERATOR_NEW_FORWARD_CUH_

#include <mxnet/base.h>
#include <stdio.h>
#include <math.h>
#define TILE_WIDTH 28
//#define  checkCuda()
namespace mxnet
{
    namespace op
    {
        
        __constant__ float constant_kernel[1250];
        
        // template<typename gpu, typename DType>
        __global__ void forward_kernel(float *y, const float *x, const float *k, const int B, const int M, const int C, const int H, const int W, const int K) {
            
            __shared__ float x_shared[28 * 28];
            
            const int H_out = H - K + 1;
            const int W_out = W - K + 1;
            
            int block_num = blockIdx.x;
            int local_h = threadIdx.y;
            int local_w = threadIdx.x;
            float sum = 0.0;
            
            x_shared[local_h * 28 + local_w] = x[block_num * 28 * 28 + local_h * 28 + local_w];
            //__syncthreads();
            
            // compute
            if (local_h < 24 && local_w < 24) {
//#pragma unroll 15
                for (int kernel_index = 0; kernel_index < 50; ++kernel_index) {
                    sum = 0.0;
                    for (int i = 0; i < 5; ++i) {
                        for (int j = 0; j < 5; ++j) {
                            sum += x_shared[(local_h + i) * 28 + local_w + j] *
                            constant_kernel[kernel_index * 25 + i * 5 + j];
                        }
                    }
                    y[block_num * 50 * 24 * 24 + local_h * 24 + local_w + kernel_index * 24 * 24] = sum;
                }
            }
        }

        template<>
        void forward<gpu, float>(mshadow::Tensor<gpu, 4, float> &y, const mshadow::Tensor<gpu, 4, float> &x, const mshadow::Tensor<gpu,4,float> &w)
        {
            
            
            const int B = x.shape_[0]; // input batch
            const int M = w.shape_[1]; // output channel number
            const int C = x.shape_[1]; // input channel number
            const int H = x.shape_[2]; // input height
            const int W = x.shape_[3]; // input width
            const int K = w.shape_[3]; // kernel size
            
            dim3 blockDim(TILE_WIDTH, TILE_WIDTH, 1);
            dim3 gridDim(B, 1, 1);
            
            cudaMemcpyToSymbol(constant_kernel, w.dptr_, sizeof(float) * 50 * 25, 0, cudaMemcpyDeviceToDevice);
            
            forward_kernel<<<gridDim, blockDim>>>(y.dptr_,x.dptr_,w.dptr_, B, M, C, H, W, K);
            
            MSHADOW_CUDA_CALL(cudaDeviceSynchronize());
            
        }
        template <typename gpu, typename DType>
        void forward(mshadow::Tensor<gpu, 4, DType> &y, const mshadow::Tensor<gpu, 4, DType> &x, const mshadow::Tensor<gpu, 4, DType> &w)
        {
            //CHECK_EQ(0,1) << "Remove this line and replace it with your implementation.";
        }
    }
}



#endif
