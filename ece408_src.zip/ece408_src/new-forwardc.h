#ifndef MXNET_OPERATOR_NEW_FORWARD_CUH_
#define MXNET_OPERATOR_NEW_FORWARD_CUH_

#define TILE_WIDTH 32
#define MASK_WIDTH 7
#define X_tile_width (TILE_WIDTH+MASK_WIDTH-1)
#include <mxnet/base.h>
#include <stdio.h>
#include <math.h>

/** This is the constant(kernel)_shared(input) memory optimization
 * Sweeping various parameters to find best values (block sizes, amount of thread coarsening)
 */

namespace mxnet
{   
    namespace op    
    {   __constant__ float W_constant[24*12][7][7];


__global__ void forward_kernel(float *y, const float *x, const float *k, const int B, const int M, const int C, const int H, const int W, const int K) {


    const int H_out = H - K + 1;
    const int W_out = W - K + 1;
    #define y4d(i3,i2,i1,i0) y[(i3) * (M * H_out * W_out) + (i2)*(H_out * W_out) + (i1)*(W_out) + i0]
    #define x4d(i3,i2,i1,i0) x[(i3) * (C * H * W) + (i2)*(H * W) + (i1)*(W) + i0]

    int n, m, h, w, p;

    __shared__ float X_shared[X_tile_width*X_tile_width];

    n = blockIdx.x;
    m = blockIdx.y;
    h = threadIdx.y;
    w = threadIdx.x;


    float acc = 0.0;

    X_shared[h*X_tile_width + w] = x4d(n, 0, h, w);

    __syncthreads();

    if((h < TILE_WIDTH) && (w < TILE_WIDTH)){
                p = 0;
                acc += W_constant[m][p][0] * X_shared[(p+h)*X_tile_width + (w)];
                acc += W_constant[m][p][1] * X_shared[(p+h)*X_tile_width + (w+1)];
                acc += W_constant[m][p][2] * X_shared[(p+h)*X_tile_width + (w+2)];
                acc += W_constant[m][p][3] * X_shared[(p+h)*X_tile_width + (w+3)];
                acc += W_constant[m][p][4] * X_shared[(p+h)*X_tile_width + (w+4)];
                acc += W_constant[m][p][5] * X_shared[(p+h)*X_tile_width + (w+5)];
                acc += W_constant[m][p][6] * X_shared[(p+h)*X_tile_width + (w+6)];


                p = 1;
                acc += W_constant[m][p][0] * X_shared[(p+h)*X_tile_width + (w)];
                acc += W_constant[m][p][1] * X_shared[(p+h)*X_tile_width + (w+1)];
                acc += W_constant[m][p][2] * X_shared[(p+h)*X_tile_width + (w+2)];
                acc += W_constant[m][p][3] * X_shared[(p+h)*X_tile_width + (w+3)];
                acc += W_constant[m][p][4] * X_shared[(p+h)*X_tile_width + (w+4)];
                acc += W_constant[m][p][5] * X_shared[(p+h)*X_tile_width + (w+5)];
                acc += W_constant[m][p][6] * X_shared[(p+h)*X_tile_width + (w+6)];

                p = 2;
                acc += W_constant[m][p][0] * X_shared[(p+h)*X_tile_width + (w)];
                acc += W_constant[m][p][1] * X_shared[(p+h)*X_tile_width + (w+1)];
                acc += W_constant[m][p][2] * X_shared[(p+h)*X_tile_width + (w+2)];
                acc += W_constant[m][p][3] * X_shared[(p+h)*X_tile_width + (w+3)];
                acc += W_constant[m][p][4] * X_shared[(p+h)*X_tile_width + (w+4)];
                acc += W_constant[m][p][5] * X_shared[(p+h)*X_tile_width + (w+5)];
                acc += W_constant[m][p][6] * X_shared[(p+h)*X_tile_width + (w+6)];

                p = 3;
                acc += W_constant[m][p][0] * X_shared[(p+h)*X_tile_width + (w)];
                acc += W_constant[m][p][1] * X_shared[(p+h)*X_tile_width + (w+1)];
                acc += W_constant[m][p][2] * X_shared[(p+h)*X_tile_width + (w+2)];
                acc += W_constant[m][p][3] * X_shared[(p+h)*X_tile_width + (w+3)];
                acc += W_constant[m][p][4] * X_shared[(p+h)*X_tile_width + (w+4)];
                acc += W_constant[m][p][5] * X_shared[(p+h)*X_tile_width + (w+5)];
                acc += W_constant[m][p][6] * X_shared[(p+h)*X_tile_width + (w+6)];

                p = 4;
                acc += W_constant[m][p][0] * X_shared[(p+h)*X_tile_width + (w)];
                acc += W_constant[m][p][1] * X_shared[(p+h)*X_tile_width + (w+1)];
                acc += W_constant[m][p][2] * X_shared[(p+h)*X_tile_width + (w+2)];
                acc += W_constant[m][p][3] * X_shared[(p+h)*X_tile_width + (w+3)];
                acc += W_constant[m][p][4] * X_shared[(p+h)*X_tile_width + (w+4)];
                acc += W_constant[m][p][5] * X_shared[(p+h)*X_tile_width + (w+5)];
                acc += W_constant[m][p][6] * X_shared[(p+h)*X_tile_width + (w+6)];



                p = 5;
                acc += W_constant[m][p][0] * X_shared[(p+h)*X_tile_width + (w)];
                acc += W_constant[m][p][1] * X_shared[(p+h)*X_tile_width + (w+1)];
                acc += W_constant[m][p][2] * X_shared[(p+h)*X_tile_width + (w+2)];
                acc += W_constant[m][p][3] * X_shared[(p+h)*X_tile_width + (w+3)];
                acc += W_constant[m][p][4] * X_shared[(p+h)*X_tile_width + (w+4)];
                acc += W_constant[m][p][5] * X_shared[(p+h)*X_tile_width + (w+5)];
                acc += W_constant[m][p][6] * X_shared[(p+h)*X_tile_width + (w+6)];

                p = 6;
                acc += W_constant[m][p][0] * X_shared[(p+h)*X_tile_width + (w)];
                acc += W_constant[m][p][1] * X_shared[(p+h)*X_tile_width + (w+1)];
                acc += W_constant[m][p][2] * X_shared[(p+h)*X_tile_width + (w+2)];
                acc += W_constant[m][p][3] * X_shared[(p+h)*X_tile_width + (w+3)];
                acc += W_constant[m][p][4] * X_shared[(p+h)*X_tile_width + (w+4)];
                acc += W_constant[m][p][5] * X_shared[(p+h)*X_tile_width + (w+5)];
                acc += W_constant[m][p][6] * X_shared[(p+h)*X_tile_width + (w+6)];

        __syncthreads();

        y4d(n, m, h, w) = acc;
    }

    #undef y4d
    #undef x4d
}
        
        
        template <>        
        void forward<gpu, float>(mshadow::Tensor<gpu, 4, float> &y, const mshadow::Tensor<gpu, 4, float> &x, const mshadow::Tensor<gpu, 4, float> &w)
        { 
            const int B = x.shape_[0];           
            const int M = y.shape_[1];         
            const int C = x.shape_[1];          
            const int H = x.shape_[2];          
            const int W = x.shape_[3];         
            const int K = w.shape_[3];
            dim3 gridDim(B, M, 1);
           dim3 blockDim(TILE_WIDTH+K-1, TILE_WIDTH+K-1, 1);

          // cudaMemcpyToSymbol(W_constant, w.dptr_, M*C*7*7*sizeof(float));

           forward_kernel<<<gridDim, blockDim>>>(y.dptr_,x.dptr_,w.dptr_, B,M,C,H,W,K);

             MSHADOW_CUDA_CALL(cudaDeviceSynchronize());
        }       
        template <typename gpu, typename DType>
           
        void forward(mshadow::Tensor<gpu, 4, DType> &y, const mshadow::Tensor<gpu, 4, DType> &x, const mshadow::Tensor<gpu, 4, DType> &w)
        {
            //CHECK_EQ(0,1) << "Remove this line and replace it with your implementation.";
        }
    }
}
#endif

